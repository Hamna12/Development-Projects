# Resume_Dashboard
I just tried to build an interactive Resume dashboard on PowerBi. DataSet was created on the basis of my Resume. 
It is just overall summary of my Resume in PowerBi format.
In this time and age, handling, understanding and analyzing data is everything. It is needless to mention that being able to drive actionable insight
is quite interesting and empowering in a way it allows an individual to work towards realistic and acieveable goals.
